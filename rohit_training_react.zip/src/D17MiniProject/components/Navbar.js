import React, { useState } from "react";
import "../Main.css";
import { useCartContext } from "../context/CartContext";
import { Link } from "react-router-dom";
import { useAuthContext } from "../context/AuthContext";
import { Badge } from "@mui/material";
import AccountCircleSharpIcon from '@mui/icons-material/AccountCircleSharp';
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
function Navbar() {
  const [showProfileOptions, setShowProfileOptions] = useState(false);
  const { cart } = useCartContext();
  const { logout } = useAuthContext();
  const {userAuth}=useAuthContext();
  return (
    <div className="navbar">
      <div className="leftNav">
        <div>Logo</div>
        <div>
          <Link
            style={{ textDecoration: "none", color: "white" }}
            to="/project"
          >
            Products
          </Link>
        </div>
        <div>
          <Link
            style={{ textDecoration: "none", color: "white" }}
            to="/project/allorders"
          >
            All Orders
          </Link>
        </div>
        <div>
          <Link
            style={{ textDecoration: "none", color: "white" }}
            to="/project/addProduct"
          >
            Add Product
          </Link>
        </div>
      </div>
      <div className="rightNav">
        {/* <div>
        <svg viewBox="0 0 24 24" height="32px" width="32px" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M2 9.1371C2 14 6.01943 16.5914 8.96173 18.9109C10 19.7294 11 20.5 12 20.5C13 20.5 14 19.7294 15.0383 18.9109C17.9806 16.5914 22 14 22 9.1371C22 4.27416 16.4998 0.825464 12 5.50063C7.50016 0.825464 2 4.27416 2 9.1371Z" fill="#a72a2a"></path> </g></svg>
        </div> */}

        <div className="cart">
          <Link
            style={{ textDecoration: "none", color: "#2f2626" }}
            to="/project/cart"
          >
            <Badge badgeContent={cart.length} color="secondary">
              <ShoppingCartIcon color="primary"/>
            </Badge>
          </Link>
        </div>

        <div className="profile">
          <div onClick={() => setShowProfileOptions(!showProfileOptions)}>
           <AccountCircleSharpIcon/>
          </div>
          {showProfileOptions && (
            <div className="profileOptions">              <div onClick={() => setShowProfileOptions(!showProfileOptions)}>
                <Link
                  style={{ textDecoration: "none", color: "black" }}
                  to="/project/myorders"
                >
                  <p>My Orders</p>
                </Link>
              </div>
              <div
                onClick={() => {
                  setShowProfileOptions(!showProfileOptions);
                  logout();
                }}
              >
                <p>Logout</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Navbar;
