import React, { useEffect, useState } from "react";
import { useProductContext } from "../context/ProductContext";
import ProductComponent from "../../D9Loops/ProductComponent";
import ProductCard from "./ProductCard";
import { Link } from "react-router-dom";
import Modal from "./Modal";

function Products() {
  const [open, setOpen] = React.useState(false);
  let { products, handleDelete, setDeleteId } = useProductContext();
  const [productToShow, setProductToShow] = useState(products);
  const [search, setSearch] = useState("");
  const handleClose = () => {
    setOpen(false);
    setDeleteId("");
  };

  const handleOpen = () => {
    setOpen(true);
  };

  //---------------------Product Search Function--------------------------------
  const handleSearch = (e) => {
    setSearch(e.target.value);
    if (!e.target.value.trim()) {
      setProductToShow(products);
    } else {
      setProductToShow(
        products.filter((item) => {
          return (item.title + item.brand + item.description + item.category)
            .toLowerCase()
            .includes(e.target.value.toLowerCase());
        })
      );
    }
  };

  useEffect(() => {
    setProductToShow(products);
  }, [products]);

  return (
    <div className="products">
      <div className="filters">
        {/* <Link to="/project/productDetails">Details</Link> */}
      </div>

      <div className="productList">
        <div
          style={{
            position: "relative",
            width: "100%",
            height: "3rem",
            margin: "10px",
            marginLeft: "33%",
          }}
        >
          <svg
            style={{ position: "absolute", top: "4px", left: "5px" }}
            width="24px"
            height="24px"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
            <g
              id="SVGRepo_tracerCarrier"
              stroke-linecap="round"
              stroke-linejoin="round"
            ></g>
            <g id="SVGRepo_iconCarrier">
              {" "}
              <g clip-path="url(#clip0_15_152)">
                {" "}
                <rect width="24" height="24" fill="white"></rect>{" "}
                <circle
                  cx="10.5"
                  cy="10.5"
                  r="6.5"
                  stroke="#000000"
                  stroke-linejoin="round"
                ></circle>{" "}
                <path
                  d="M19.6464 20.3536C19.8417 20.5488 20.1583 20.5488 20.3536 20.3536C20.5488 20.1583 20.5488 19.8417 20.3536 19.6464L19.6464 20.3536ZM20.3536 19.6464L15.3536 14.6464L14.6464 15.3536L19.6464 20.3536L20.3536 19.6464Z"
                  fill="#000000"
                ></path>{" "}
              </g>{" "}
              <defs>
                {" "}
                <clipPath id="clip0_15_152">
                  {" "}
                  <rect width="24" height="24" fill="white"></rect>{" "}
                </clipPath>{" "}
              </defs>{" "}
            </g>
          </svg>
          <input
            type="search"
            value={search}
            onChange={handleSearch}
            placeholder="Search Product..."
            style={{
              height: "2rem",
              paddingLeft: "30px",
              borderRadius: "10px",
              width: "20rem",
            }}
          />
        </div>
        {productToShow.length > 0 &&
          productToShow.map((data) => (
            <ProductCard key={data.id} data={data} handleOpen={handleOpen} />
          ))}
      </div>
      <Modal isOpen={open} onClose={handleClose}>
        <div style={{ position: "relative" }}>
          <h3
            style={{ marginTop: "30px", position: "absolute", width: "100%" }}
          >
            Do you really want to delete this item?
          </h3>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
              marginTop: "90px",
              position: "absolute",
            }}
          >
            <button
              style={{
                height: "1.5rem",
                width: "5rem",
                backgroundColor: "rgb(79 70 229)",
                border: "none",
                color: "white",
                cursor: "pointer",
                borderRadius: "10px",
              }}
              onClick={() => {
                handleDelete();
                handleClose();
              }}
            >
              Yes
            </button>
            <button
              style={{
                height: "1.5rem",
                width: "5rem",
                backgroundColor: "rgb(79 70 229)",
                border: "none",
                color: "white",
                cursor: "pointer",
                borderRadius: "10px",
              }}
              onClick={handleClose}
            >
              No
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
export default Products;
