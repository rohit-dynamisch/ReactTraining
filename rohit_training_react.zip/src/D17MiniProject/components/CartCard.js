import React, { useEffect, useState } from "react";
import { useCartContext } from "../context/CartContext";

function CartCard({ item }) {
  const { updateCart, cart } = useCartContext();
  const [cartData, setCartData] = useState(item);

  useEffect(() => {
    setCartData(item);
  }, [item]);

  const handleChange = (e) => {
    setCartData((temp) => {
      return {
        ...temp,
        quantity: e.target.value,
      };
    });

    updateCart({
      ...cartData,
      quantity: parseInt(e.target.value),
    });
  };

  const { removeFromCart } = useCartContext();
  return (
    <div className="cartItem">
      <div className="cartItemImage">
        <img src={item.thumbnail}></img>
      </div>
      <div className="cartItemInfo">
        <p>{item.title}</p>
        <p>{item.brand}</p>
        <p>{item.category}</p>
        <select
          value={cartData.quantity ? cartData.quantity : 1}
          onChange={handleChange}
        >
          <option value={1}>1</option>
          <option value={2}>2</option>
          <option value={3}>3</option>
          <option value={4}>4</option>
          <option value={5}>5</option>
        </select>
      </div>
      <div className="cartItemPrice">
        <p>₹{item.price}</p>
        {item.discountPercentage && item.discountPercentage > 0 && (
          <p>{item.discountPercentage}% off</p>
        )}
        <p
          onClick={() => removeFromCart(item.id)}
          style={{
            color: "rgb(79 70 229)",
            fontWeight: "bolder",
            cursor: "pointer",
          }}
        >
          Remove
        </p>
      </div>
    </div>
  );
}

export default CartCard;
