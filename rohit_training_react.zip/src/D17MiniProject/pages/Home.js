import React from 'react'
import Navbar from '../components/Navbar'
import Products from '../components/Products'
import EditProduct from './ProductForm'

function Home() {
  return (
    <div>
      <Products/>
    </div>
  )
}

export default Home