import React, { useContext } from 'react'
import { useOrderContext } from '../context/OrderContext'
import MyOrderItem from '../components/MyOrderItem';

function MyOrder() {
    const {order}=useOrderContext();
  return (
    <div>
      <div>
        <h2 style={{textDecoration:"underline",textAlign:"center"}}>My Orders</h2>
        <div className='myOrderDiv'>
        {
            order.map(item=> <MyOrderItem item={item}/>)
        }
        </div>
      </div>
    </div>
  )
}

export default MyOrder
