import { useContext, useEffect } from "react";
import { createContext, useState } from "react";

const AuthContext = createContext({
  userAuth: null,
  login: () => {},
  logout: () => {},
});

export function AuthContextProvider({ children }) {
  const [userAuth, setUserAuth] = useState(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) login(user);
  }, []);

  function login(userData) {
    setUserAuth(userData);
    localStorage.setItem("user", JSON.stringify(userData));
  }

  function logout() {
    setUserAuth(null);
    localStorage.removeItem("user");
  }

  return (
    <AuthContext.Provider value={{ userAuth, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const { userAuth, login, logout } = useContext(AuthContext);
  return { userAuth, login, logout };
}
